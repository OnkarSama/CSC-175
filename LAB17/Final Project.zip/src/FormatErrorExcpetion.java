public class FormatErrorExcpetion extends NumberFormatException{

    public FormatErrorExcpetion() {

    }
}
