public class Checking extends Account{

    private Money overdraftMaximum;
    public Checking(String name, String id, Money balance) {
        super(name, id, balance);
        this.overdraftMaximum = new Money(100,0);
    }

    @Override
    public void withdraw(Money amount) {


        if(lessThan(amount,overdraftMaximum)){
            super.withdraw(amount);
        } else {
            throw new InsufficientFundsException("Trying to withdraw too much");
        }



    }

    public boolean lessThan(Money amount, Money overdraftMaximum) {
        return amount.compareTo(getBalance().add(overdraftMaximum)) <= 0;
    }
}
