import java.util.Scanner;
import java.io.File;
import java.io.IOException;

// Driver class for Bank project

public class ATM {
    public static void main(String[] args) {
        try {

            String fileName = "BankAccounts.txt"; // made using ChatGPT for the accounts
            // Read data from a file into a Bank.
            // Each line of the file has info for one account.
            BankInterface myBank = readFromFile(fileName);

            IOHandlerInterface ioHandlerDialog = new IOHandlerDialog();
            IOHandlerInterface ioHandlerStandard = new IOHandlerStandard();

            String userIdNumber = readUserId(ioHandlerDialog);

            if(isValid(myBank, userIdNumber)) {
                ioHandlerDialog.put("Account Found " + myBank.search(userIdNumber).toString());
            } else {
                ioHandlerDialog.put("Account not Found.");
            }

//            String userIdNumber = readUserId(ioHandlerStandard);
//
//            if(isValid(myBank, userIdNumber)) {
//                ioHandlerStandard.put("Account Found" + myBank.search(userIdNumber).toString());
//            } else {
//                ioHandlerStandard.put("Account not Found");
//            }


            // Print all the data stored in the bank.
            for(int i = 0; i < 5; i++){
                System.out.println();
            }

            System.out.println(myBank);

        } // end try
        catch (IOException ioe) {
            System.out.println("IOException in main: " + ioe.getMessage());
            ioe.printStackTrace();
        } // end catch
        catch (Exception e) {
            System.out.println("Exception in main: " + e.getMessage());
            e.printStackTrace();
        } // end catch
    } // end main


    /**
     * It uses and instance of BankInterface to create a bank then reads from BankAccounts.txt and adds those accounts
     * to the instance of bank
     * @param fileName is the file that it will read for account info
     * @return myBank it returns the bank after adding all the accounts
     */
    public static BankInterface readFromFile(String fileName) throws IOException {
        // Create a bank.
        BankInterface myBank = new Bank2("VOD"); // name of the bank

        // Open a file for reading.
        Scanner inputSource = new Scanner(new File(fileName));  // reading the file

        // while there are more tokens to read from the input source...
        while (inputSource.hasNext()){  // looping while the inputSource has another account

            // Read one line of input from the file into an Account object
            Account acct = InputManager.readOneAccountFrom(inputSource);

            // Store the account info in the bank.
        myBank.addAccount(acct);

        } // end while


        return myBank;

    } // end readFromFile

    public static String readUserId(IOHandlerInterface ioh) {
        return ioh.get("Enter your UserID number: ");
    }

    public static boolean isValid(BankInterface bank, String id){

        if(bank.search(id) == null){
            return false;
        } else {
            return bank.search(id).getId().equals(id);
        }

    }

} // end ATM