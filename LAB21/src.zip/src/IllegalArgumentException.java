public class IllegalArgumentException extends RuntimeException {

    public  IllegalArgumentException(String s){
        super(s);
    }
}
